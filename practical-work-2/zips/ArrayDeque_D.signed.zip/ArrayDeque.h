#ifndef ArrayDeque_h
#define ArrayDeque_h

#include <cstddef> // std::size_t
#include <ostream> // std::ostream
// Ajoutez si nécessaire d'autres inclusions de librairies

#include <cstring>
#include <memory>


template < class T >
class ArrayDeque {
public:
   using value_type = T;
   using reference = T&;
   using const_reference = const T&;
   using pointer = T*;
   using size_type = std::size_t;

   ArrayDeque(size_type _capacite = 0) : debut(0),
                                         taille(0),
                                         capacite(_capacite),
                                         buffer(nullptr) {
      if (capacite)
         buffer = reinterpret_cast<pointer> (
                 ::operator new(capacite * sizeof(value_type)));
   }

   // Placez ici les méthodes publiques nécessaires pour passer le codecheck

   ArrayDeque(const ArrayDeque<T> &rhs) : ArrayDeque(rhs.capacite) {
            for (size_type i = 0; i < rhs.size(); ++i) {
                new(&buffer[i_physique(i)]) value_type(std::move(rhs.buffer[i_physique(i, rhs.capacite, rhs.debut)]));
                ++taille;
            }
    }
	
	ArrayDeque(const ArrayDeque<T> &rhs, const size_type new_capacite) : ArrayDeque(new_capacite) {
        for (size_type i = 0; i < rhs.size(); ++i) {
            new(&buffer[i_physique(i)]) value_type(std::move(rhs.buffer[i_physique(i, rhs.capacite, rhs.debut)]));
            ++taille;
        }
    }
	
	 ~ArrayDeque() {
        for (size_type i = 0; i < taille; ++i)
            std::destroy_at(buffer + i_physique(i));
        ::operator delete(buffer);
    }
    
    size_type size() const noexcept { return taille; };
    size_type capacity() const noexcept { return capacite; };
    bool empty() const noexcept { return taille == 0; };
    reference front() { return at(0); };
    const_reference front() const { return at(0); };
    reference back() { return at(taille - 1); };
    const_reference back() const { return at(taille - 1); };
    void push_front(const_reference value) {
      if (taille >= capacite){
        copy_buffer_new_capacity(new_capacity());
      }
      size_t avant = i_physique(capacite - 1);
      new(&buffer[avant]) value_type(value);
      debut = avant;
      ++taille;
    }
    void push_back(const_reference value){
      if (taille >= capacite){
        copy_buffer_new_capacity(new_capacity());
	  }
      new(&buffer[i_physique(taille)]) value_type(value);
      ++taille;
    }
    void pop_front(){
      std::destroy_at(buffer + i_physique(0));
      debut = i_physique(1);
      --taille;
    }
    void pop_back(){
      std::destroy_at(buffer + i_physique(taille - 1));
      --taille;
    }

    void swap(ArrayDeque<T>& rhs){
      using std::swap;
      swap(buffer, rhs.buffer);
      swap(debut, rhs.debut);
      swap(taille, rhs.taille);
      swap(capacite, rhs.capacite);
    }
    void shrink_to_fit(){
      if (taille == capacite) return;
      copy_buffer_new_capacity(taille);
    }

    constexpr reference operator[]( size_type i ) { return at(i); };
    constexpr const_reference operator[]( size_type i ) const { return at(i); };

    ArrayDeque<T>& operator=(const ArrayDeque<T>& rhs){
      if(this != &rhs){
        ArrayDeque<T> tmp(rhs);
        swap(tmp);
      }
      return *this;
    }


private:
   pointer buffer;
   size_type capacite;
   size_type debut;
   size_type taille;

   // Placez ici les méthodes privées qui permettent de rendre votre code plus clair

   reference at(size_type i) noexcept { return buffer[i_physique(i)]; };
   const_reference at(size_type i) const noexcept { return buffer[i_physique(i)]; };
   size_t i_physique(size_t i_logique){
      return (debut + i_logique) % capacite;
   }
   size_t i_physique(size_t i_logique) const{
      return (debut + i_logique) % capacite;
   }
   size_t i_physique(size_t i_logique, size_t capacite, size_t debut){
      return (debut + i_logique) % capacite;
   }
   size_type new_capacity(){
      if (!capacite){
        return 1;
      } else{
        return 2*capacite;
      }
   }
   
   void copy_buffer_new_capacity(size_t new_capacite){
    ArrayDeque<T> temp(*this, new_capacite);
    swap(temp);
   }

};

template <typename T> inline
std::ostream& operator<<(std::ostream& s,
                         const ArrayDeque<T>& v) {
   s << "(" << v.size() << "/" << v.capacity() << ") : ";
   if (not v.empty())
      s << v.front() << " -> " << v.back() << " : ";
   s << "[";
   for (int i = 0; i < v.size(); ++i) {
      s << v[i];
      if (i != v.size() - 1)
         s << ", ";
   }
   s << "]";
   return s;
}

#endif /* ArrayDeque_hpp */
