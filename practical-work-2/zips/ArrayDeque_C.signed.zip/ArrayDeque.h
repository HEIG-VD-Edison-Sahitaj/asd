#ifndef ArrayDeque_h
#define ArrayDeque_h

#include <cstddef> // std::size_t
#include <ostream> // std::ostream
// Ajoutez si nécessaire d'autres inclusions de librairies

#include <cstring>


template < class T >
class ArrayDeque {
public:
   using value_type = T;
   using reference = T&;
   using const_reference = const T&;
   using pointer = T*;
   using size_type = std::size_t;

   ArrayDeque(size_type _capacite = 0) : debut(0),
                                         taille(0),
                                         capacite(_capacite),
                                         buffer(nullptr) {
      if (capacite)
         buffer = reinterpret_cast<pointer> (
                 ::operator new(capacite * sizeof(value_type)));
   }

   // Placez ici les méthodes publiques nécessaires pour passer le codecheck

   ArrayDeque(const ArrayDeque<T> &rhs) : debut(0),
                                           taille(0),
                                           capacite(rhs.capacite),
                                           buffer(nullptr) {
        if (capacite)
            buffer = reinterpret_cast<pointer> (
                    ::operator new(capacite * sizeof(value_type)));
        for (size_type i = 0; i < rhs.size(); ++i)
            push_back(rhs[i]);
    }
    
    size_type size() const noexcept { return taille; };
    size_type capacity() const noexcept { return capacite; };
    bool empty() const noexcept { return taille == 0; };
    reference front() { return at(0); };
    const_reference front() const { return at(0); };
    reference back() { return at(taille - 1); };
    const_reference back() const { return at(taille - 1); };
    void push_front(const_reference value) {
       if (taille >= capacite){
        size_type old_capacite = capacite;
        capacite = new_capacity();
        auto tmp = reinterpret_cast<pointer> (
                ::operator new(capacite * sizeof(value_type)));
        for (size_type i = 0; i < taille; ++i) {
            new(&tmp[i_physique(i, capacite)]) value_type(buffer[i_physique(i, old_capacite)]);
            buffer[i_physique(i, old_capacite)].~value_type();
        }
        delete[] buffer;
        buffer = tmp;
    }

      size_t avant = i_physique(capacite - 1);
      new(&buffer[avant]) value_type(value);
      debut = avant;
      ++taille;
    }
    void push_back(const_reference value){
       if (taille >= capacite){
        size_type old_capacite = capacite;
        capacite = new_capacity();
        auto tmp = reinterpret_cast<pointer> (
                ::operator new(capacite * sizeof(value_type)));
        for (size_type i = 0; i < taille; ++i) {
            new(&tmp[i_physique(i, capacite)]) value_type(buffer[i_physique(i, old_capacite)]);
            buffer[i_physique(i, old_capacite)].~value_type();
        }
        delete[] buffer;
        buffer = tmp;
    }

      new(&buffer[i_physique(taille)]) value_type(value);
      ++taille;
    }
    void pop_front(){
       buffer[i_physique(0)].~value_type();
      debut = i_physique(1);
      --taille;
    }
    void pop_back(){
      buffer[i_physique(taille - 1)].~value_type();
      --taille;
    }

    void swap(ArrayDeque<T>& rhs){
       using std::swap;
      swap(buffer, rhs.buffer);
      swap(debut, rhs.debut);
      swap(taille, rhs.taille);
      swap(capacite, rhs.capacite);
    }
    void shrink_to_fit(){
      if (taille == capacite) return;
      pointer new_buffer = reinterpret_cast<pointer> (
            ::operator new(taille * sizeof(value_type)));
      for (size_type i = 0; i < taille; ++i)
        new_buffer[i] = buffer[i_physique(i)];
      ::operator delete(buffer);
      buffer = new_buffer;
      capacite = taille;
      debut = 0;
    }

    constexpr reference operator[]( size_type i ) { return at(i); };
    constexpr const_reference operator[]( size_type i ) const { return at(i); };

    ArrayDeque<T>& operator=(const ArrayDeque<T>& rhs){
      if(this != &rhs){
        ArrayDeque<T> tmp(rhs);
        swap(tmp);
      }
      return *this;
    }

    ~ArrayDeque() {
        for (size_type i = 0; i < taille; ++i)
            buffer[(debut + i) % capacite].~value_type();
        ::operator delete(buffer);
    }


private:
   pointer buffer;
   size_type capacite;
   size_type debut;
   size_type taille;

   // Placez ici les méthodes privées qui permettent de rendre votre code plus clair

reference at(size_type i) { return buffer[i_physique(i)]; };
   const_reference at(size_type i) const { return buffer[i_physique(i)]; };
   size_t i_physique(size_t i_logique){
      auto ip = (debut + i_logique) % capacite;
      if (ip >= 0){
        return ip;
      } else{
        return ip + capacite;
      }
   }
   size_t i_physique(size_t i_logique) const{
      auto ip = (debut + i_logique) % capacite;
      if (ip >= 0){
        return ip;
      } else{
        return ip + capacite;
      }
   }
   size_t i_physique(size_t i_logique, size_t capacite){
      auto ip = (debut + i_logique) % capacite;
      if (ip >= 0){
        return ip;
      } else{
        return ip + capacite;
      }
   }
   size_type new_capacity(){
      if (!capacite){
        return 1;
      } else{
        return 2*capacite;
      }
   }


};

template <typename T> inline
std::ostream& operator<<(std::ostream& s,
                         const ArrayDeque<T>& v) {
   s << "(" << v.size() << "/" << v.capacity() << ") : ";
   if (not v.empty())
      s << v.front() << " -> " << v.back() << " : ";
   s << "[";
   for (int i = 0; i < v.size(); ++i) {
      s << v[i];
      if (i != v.size() - 1)
         s << ", ";
   }
   s << "]";
   return s;
}

#endif /* ArrayDeque_hpp */
